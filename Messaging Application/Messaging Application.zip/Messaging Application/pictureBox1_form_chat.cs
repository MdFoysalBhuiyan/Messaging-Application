﻿namespace Messaging_Application
{
    internal class pictureBox1_form_chat
    {
    }
}