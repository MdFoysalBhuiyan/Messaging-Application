﻿using System.Drawing;

namespace Messaging_Application
{
    internal class Usercontrol1
    {
        public Image Image1 { get; internal set; }
        public string Text1 { get; internal set; }
        public string Title { get; internal set; }
    }
}